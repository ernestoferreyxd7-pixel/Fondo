# Scorpy Safio Title Screen (Fabric 1.21.1)

Reemplaza el menú principal por uno con "SCORPY / SAFIO" y "by sefixz".
Botones: JUGAR (abre multijugador), OPCIONES, SALIR.

## Compilar
- Local: instala Java 21 + Gradle 8.10+ y corre `gradle build`. El jar queda en `build/libs/`.
- Sin PC: sube esta carpeta a un repo de GitHub; en la pestaña Actions corre "build"
  y descarga el artefacto `scorpysafio-mod`.

## Personalizar
- Textos: constantes al inicio de `ScorpyTitleScreen.java`.
- Fondo propio: PNG de 1920x1080 en
  `src/main/resources/assets/scorpysafio/textures/gui/background.png`.
- Es un mod de cliente: cada jugador debe tenerlo en su carpeta `mods`.
